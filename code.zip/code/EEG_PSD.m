clear;clc
data=load('subjects.mat');
data_analyse_1=[data.MD_cC_1_64cha(51:300,:,:) data.MD_iC_1_64cha(51:300,:,:)];
data_analyse_2=[data.MD_cC_2_64cha(51:300,:,:) data.MD_iC_2_64cha(51:300,:,:)];
data_m_tmp_1=mean(data_analyse_1,2)
data_m_tmp_2=mean(data_analyse_2,2);
data_m_1=reshape(data_m_tmp_1,250,64);
data_m_2=reshape(data_m_tmp_2,250,64);
data_cha_1=data_m_1(:,11);
data_cha_2=data_m_2(:,11);
x1=smooth(data_cha_1,10);
x2=smooth(data_cha_2,10);
N=250;
fs=250;
t=0:1/fs:(N-1)/fs;
figure
%periodogram
[Pxx1,f1] = periodogram(x1,rectwin(length(x1)), N, fs);
freq1=0:fs/length(x1):fs/2;
train_y1=10*log10(Pxx1);
for i= 1:size(train_y1,2)
    if train_y1(1,i)< -40
        train_y1(1,i)=-40;
    end
end
[Pxx2,f2] = periodogram(x2,rectwin(length(x2)), N, fs);
freq2=0:fs/length(x2):fs/2;
train_y2=10*log10(Pxx2);
for i= 1:size(train_y2,2)
    if train_y2(1,i)< -40
        train_y2(1,i)=-40;
    end
end
plot(freq1,train_y1,'r','linestyle','-',LineWidth=2);
hold on
plot(freq2,train_y2,'b','linestyle','--',LineWidth=2);
grid on;xlim([0 50]);
title('Consistent');
xlabel('frequency/Hz');
ylabel('power/dB');
legend('Higher altitude','Lower altitude')
set(gca,'fontsize',30)
