clear;clc
data=load('subjects.mat');
data_analyse_1=data.MD_cI_1_64cha;
data_analyse_2=data.MD_iI_1_64cha;
data_analyse=[data_analyse_1(51:300,:,:) data_analyse_2(51:300,:,:)];
data_m_tmp=mean(data_analyse,2);
data_m=reshape(data_m_tmp,250,64);
data_cha=data_m(:,11);
lowpass=8;
highpass=30;
fs=250;
N=250;
n=0:N-1;
Wn=[lowpass*2 highpass*2]/fs;%0.5-50Hz
[k,l]=butter(2,Wn);%IIR
data_analyse_f=filtfilt(k,l,data_cha);
fs=250;
sss= data_analyse_f;
wavename='cmor3-3';
totalscal=1024;
Fc=centfrq(wavename); %Fc=3
c=2*Fc*totalscal;c=1536
scals=c./(1:totalscal);
f=scal2frq(scals,wavename,1/fs); 
coefs = cwt(sss,scals,wavename); 
t=0:1/fs:size(sss)/fs;
figure
imagesc(t,f,abs(coefs));
set(gca,'YDir','normal')
colorbar;
% caxis(0:1);
xlabel('Time t/s');
ylabel('Frequency f/Hz');ylim([lowpass,highpass]);
% title('title');
set(gca,'fontsize',75)
colormap('jet');
