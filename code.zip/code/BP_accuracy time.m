clc
clear
close
[file,path]=uigetfile('.mat','multiselect','on');
n=length(file);
data_time_iC=zeros(n,1);
data_time_cI=zeros(n,1);
data_time_cC=zeros(n,1);
data_time_iI=zeros(n,1);
ratio_time_iC=zeros(n,1);
ratio_time_cI=zeros(n,1);
ratio_time_cC=zeros(n,1);
ratio_time_iI=zeros(n,1);
for i=1:n
    cd(path);
    data=importdata(file{i});
    time=data.result(:,202:321);
    time_strat=data.mouse_response_time(4,:);
    a=1:120;
    time(8,:)=a;
    k1=0;k2=0;k3=0;k4=0;
    index=[1 4 1 1 4 1 4 4 1 2 2 1 1 2 1 2 1 2 1 1
        2 1 2 2 1 2 1 2 2 1 2 1 2 1 2 1 2 1 2 1
        3 2 3 2 3 3 2 2 3 4 4 3 4 3 4 3 4 3 3 4
        4 3 4 3 3 4 3 4 4 3 4 3 4 3 4 4 3 4 3 3
        4 1 4 4 1 4 1 2 2 1 2 1 2 1 2 1 2 1 2 1
        1 2 1 1 2 1 2 2 1 2 2 1 1 2 1 2 1 2 1 1]; %Stimulus sequence
    for j=1:120
        if index(j)==1
            k1=k1+1;
            time_iC(:,k1)=time(:,j);
        end
        if index(j)==2
            k2=k2+1;
            time_cI(:,k2)=time(:,j);
        end
        if index(j)==3
            k3=k3+1;
            time_cC(:,k3)=time(:,j);
        end
        if index(j)==4
            k4=k4+1;
            time_iI(:,k4)=time(:,j);
        end
    end
    %iC
    time_iC_1=time_iC(1,:);
    x=time_iC_1~=1;
    time_iC_1(x)=[];
    a=length(time_iC_1);
    r_time_iC=a/40;
    ratio_time_iC(i,:)=r_time_iC;
    clear a
    %cI
    time_cI_1=time_cI(1,:);
    x=time_cI_1~=2;
    time_cI_1(x)=[];
    a=length(time_cI_1);
    r_time_cI=a/36;
    ratio_time_cI(i,:)=r_time_cI;
    clear a
    %cC
    time_cC_1=time_cC(1,:);
    x=time_cC_1~=1;
    time_cC_1(x)=[];
    a=length(time_cC_1);
    r_time_cC=a/20;
    ratio_time_cC(i,:)=r_time_cC;
    clear a
    %iI
    time_iI_1=time_iI(1,:);
    x=time_iI_1~=2;
    time_iI_1(x)=[];
    a=length(time_iI_1);
    r_time_iI=a/24;
    ratio_time_iI(i,:)=r_time_iI;
    clear a
    %%反应时间
    %iC
    t_iC=zeros(40,1);
    for k=2:40
        t1=time_iC(:,k);
        h1=t1(5,:);
        m1=t1(6,:);
        s1=t1(7,:);
        num=t1(8,:);
        t1_s=h1*3600+m1*60+s1;
        t2=time(:,(num-1));
        h2=t2(5,:);
        m2=t2(6,:);
        s2=t2(7,:);
        t2_s=h2*3600+m2*60+s2;
        t_s=t1_s-t2_s-1;
        t_iC(k,:)=t_s;
    end
    t_iC(1,:)=time(5,1)*3600+time(6,1)*60+time(7,1)-(time_strat(:,4)*3600+time_strat(:,5)*60+time_strat(:,6)+8.2);
    x=abs(t_iC)>4;
    t_iC(x)=[];
    t_iC_mean=mean(t_iC);
    data_time_iC(i,:)=t_iC_mean;
    %cI
    t_cI=zeros(36,1);
    for k=1:36
        t1=time_cI(:,k);
        h1=t1(5,:);
        m1=t1(6,:);
        s1=t1(7,:);
        num=t1(8,:);
        t1_s=h1*3600+m1*60+s1;
        t2=time(:,(num-1));
        h2=t2(5,:);
        m2=t2(6,:);
        s2=t2(7,:);
        t2_s=h2*3600+m2*60+s2;
        t_s=t1_s-t2_s-1;
        t_cI(k,:)=t_s;
    end
    x=abs(t_cI)>4;
    t_cI(x)=[];
    t_cI_mean=mean(t_cI);
    data_time_cI(i,:)=t_cI_mean;
    %cC
    t_cC=zeros(20,1);
    for k=1:20
        t1=time_cC(:,k);
        h1=t1(5,:);
        m1=t1(6,:);
        s1=t1(7,:);
        num=t1(8,:);
        t1_s=h1*3600+m1*60+s1;
        t2=time(:,(num-1));
        h2=t2(5,:);
        m2=t2(6,:);
        s2=t2(7,:);
        t2_s=h2*3600+m2*60+s2;
        t_s=t1_s-t2_s-1;
        t_cC(k,:)=t_s;
    end
    x=abs(t_cC)>4;
    t_cC(x)=[];
    t_cC_mean=mean(t_cC);
    data_time_cC(i,:)=t_cC_mean;
    %iI
    t_iI=zeros(24,1);
    for k=1:24
        t1=time_iI(:,k);
        h1=t1(5,:);
        m1=t1(6,:);
        s1=t1(7,:);
        num=t1(8,:);
        t1_s=h1*3600+m1*60+s1;
        t2=time(:,(num-1));
        h2=t2(5,:);
        m2=t2(6,:);
        s2=t2(7,:);
        t2_s=h2*3600+m2*60+s2;
        t_s=t1_s-t2_s-1;
        t_iI(k,:)=t_s;
    end
    x=find(abs(t_iI)>4);
    t_iI(x)=[];
    t_iI_mean=mean(t_iI);
    data_time_iI(i,:)=t_iI_mean;
end
reaction_time_C=mean([data_time_cC data_time_iC],2);
reaction_time_I=mean([data_time_cI data_time_iI],2);
accuracy_C=mean([ratio_time_cC ratio_time_iC],2);
accuracy_I=mean([ratio_time_cI ratio_time_iI],2);
ratio_C=accuracy_C./reaction_time_C;
ratio_I=accuracy_I./reaction_time_I;
data_save=[ratio_C ratio_I];
clearvars -except data_save