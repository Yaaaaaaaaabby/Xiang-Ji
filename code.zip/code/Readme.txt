1. BP_accuracy time.m
This program is designed to process behavioral data and can calculate the reaction time and accuracy for each participant.
2. EEG_PSD.m
This program can calculate the power spectral density (PSD) of EEG data.
3. EEG_smallwave.m
This program can perform time-frequency analysis on EEG data using wavelet transform.
4. fft_power.m
This program is capable of transforming time-domain EEG data into the frequency domain.